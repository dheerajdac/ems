import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

public class buffer {
	public  static volatile List<String> l = new ArrayList<>(); 
	public  static volatile int counter =0;

}

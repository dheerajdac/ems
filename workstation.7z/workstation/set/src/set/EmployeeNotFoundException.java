package set;

public class EmployeeNotFoundException extends Exception {
	
	private static final long serialVersionUID = -1408835601150462829L;

	public EmployeeNotFoundException() {
	}
}

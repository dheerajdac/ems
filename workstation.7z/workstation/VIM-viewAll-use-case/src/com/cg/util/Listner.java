package com.cg.util;

public class Listner {

	public Listner(){
		// TODO Auto-generated constructor stub
	}

}

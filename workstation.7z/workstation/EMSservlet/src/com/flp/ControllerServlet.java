package com.flp;


import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.flp.ems.domain.Department;
import com.flp.ems.domain.Employee;
import com.flp.ems.domain.Key;
import com.flp.ems.domain.Project;
import com.flp.ems.domain.Role;
import com.flp.ems.service.EmployeeServiceImpl;
import com.flp.ems.util.Validate;


//TODO 1 Import appropriate classes

//Follow TODOs (if available)
/**
 * 
 * This is a ControllerServlet class
 * @see java.lang.Object
 * @author Abhishek
 * 
 *
 */

public class ControllerServlet extends HttpServlet
{
    private static final String ACTION_KEY = "action";
    private static final String VIEW_CAR_LIST_ACTION = "viewList";
    private static final String ADD_CAR_ACTION = "add";
    private static final String SAVE_CAR_ACTION = "save";
    private static final String EDIT_CAR_ACTION = "edit";
    private static final String DELETE_CAR_ACTION = "delete";
    private static final String ERROR_KEY = "errorMessage";
    EmployeeServiceImpl service =new EmployeeServiceImpl();

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        //TODO 2 Invoke processRequest
    	processRequest(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws IOException, ServletException {
        //TODO 3 Invoke processRequest
    	processRequest(request, response);
    }

    /**
     * This method will process request based on action performed on screen. 
     * @param request				HttpServletRequest
     * @param response				HttpServletResponse
     * @throws ServletException		if error occurs
     * @throws IOException			if error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String actionName = request.getParameter(ACTION_KEY);
        String destinationPage = null; 
        // perform action
        if(VIEW_CAR_LIST_ACTION.equals(actionName))
        {            
        	List employeelist = service.getAllEmployee();
			request.setAttribute("employeelist", employeelist);
        	RequestDispatcher rd = getServletContext().getRequestDispatcher("/list.jsp");
        	rd.forward(request, response);
        }
        else if(ADD_CAR_ACTION.equals(actionName))
        {
        	Employee em = new Employee();
        	em.setEmployeeId(new Key("dhee-0"));
        	request.setAttribute("em", em);
        	RequestDispatcher rd = getServletContext().getRequestDispatcher("/add.jsp");
        	rd.forward(request, response);
        }  
        else if(EDIT_CAR_ACTION.equals(actionName))
        {
        	Employee em = service.SearchEmployee(Integer.parseInt(request.getParameter("id")));
        	request.setAttribute("em", em);
        	RequestDispatcher rd = getServletContext().getRequestDispatcher("/add.jsp");
        	rd.forward(request, response);
        }        
        else if(SAVE_CAR_ACTION.equals(actionName))
        {
        	HashMap entry= new HashMap<>();
    		entry.put(0, request.getParameter("email"));
    		entry.put(1, request.getParameter("name"));
    		entry.put(2,request.getParameter("phone"));
    		entry.put(3, request.getParameter("address"));
    		entry.put(4, formatDate(request.getParameter("dob")));
    		entry.put(5, formatDate(request.getParameter("doj")));
    		entry.put(6, getDepartment(request.getParameter("department")));
    		entry.put(7, getProject(request.getParameter("project")));
    		entry.put(8, getrole(request.getParameter("role")));
        	if(Integer.parseInt(request.getParameter("id"))==0){
        		service.AddEmployee(entry);
        	}
        	else
        	{
        		service.ModifyEmployee(Integer.parseInt(request.getParameter("id")), entry);
        	}
        	RequestDispatcher rd = getServletContext().getRequestDispatcher("/controller?action=viewList");
        	rd.forward(request, response);
        	
        	
        }
        else if(DELETE_CAR_ACTION.equals(actionName))
        {
        	service.RemoveEmployee(Integer.parseInt(request.getParameter("id")));
        	RequestDispatcher rd = getServletContext().getRequestDispatcher("/controller?action=viewList");
        	rd.forward(request, response);
        }                    
        else
        {
        }
       // System.out.println("dheeraj");
      //  RequestDispatcher rd = request.getRequestDispatcher("/carList.jsp");
        //  	System.out.println("controller?action=viewCarList");
       //   	rd.forward(request, response);
        //TODO 9 Use appropriate Servlet API to forward the request to 
		//appropriate destination page set in above if else blocks depending on action.
    }

	private Role getrole(String id) {
		// TODO Auto-generated method stub
		return service.getRole(Integer.parseInt(id));
	}

	private Project getProject(String id) {
		// TODO Auto-generated method stub
		return service.getProject(Integer.parseInt(id));
	}

	private Department getDepartment(String id) {
		// TODO Auto-generated method stub
		return service.getDepartment(Integer.parseInt(id));
	}
	
	private Date formatDate(String startDateString ){
	    DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
	    Date date = null;
	    try {
	        date = df.parse(startDateString);
	        df.format(date);
	    } catch (ParseException e) {
	    }
	    return date;
	}
}

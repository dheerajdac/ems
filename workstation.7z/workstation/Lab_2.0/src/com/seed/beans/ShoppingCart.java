package com.seed.beans;

import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;
import java.util.TreeSet;

import jdk.nashorn.internal.runtime.PrototypeObject;

//TODO:0	Modification required
public class ShoppingCart {
	private java.util.Collection<Integer> productIds;	

	public ShoppingCart() {
		productIds = new LinkedList<Integer>();
	}	
	
	public java.util.Set<Integer> getProductSet() {
		Set<Integer> set = new TreeSet<Integer>();
		for(Integer i : productIds){
			set.add(i);
		}
		return set;
//		TODO:2 return set of product ids stored in this shopping cart
	}

	public void setProductList(String[] newProductIds) {
//		TODO:3	add newProductIds into existing list of product ids
		for(String id:newProductIds){
			productIds.add(Integer.parseInt(id));
		}
	}
	
	
	public static void main(String[] args) {
		String[] s = {"1","2"};
		ShoppingCart c = new ShoppingCart();
		c.setProductList(s);
		c.getProductSet();
		
		
	}
}

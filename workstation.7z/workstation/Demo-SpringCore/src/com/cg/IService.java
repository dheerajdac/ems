package com.cg;

import java.util.List;

public interface IService {

	public List<String> getMessages();
	
	
}

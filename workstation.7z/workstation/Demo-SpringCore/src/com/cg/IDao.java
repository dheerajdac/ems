package com.cg;

import java.util.List;

public interface IDao {
	public List<String> getMessages();
}

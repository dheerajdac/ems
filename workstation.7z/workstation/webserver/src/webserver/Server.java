package webserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args) throws IOException {
		ServerSocket server = new ServerSocket(8080);
		System.out.println("waiting");
		Socket soc =server.accept();
		System.out.println(soc);
		
		InputStream in = soc.getInputStream();
		InputStreamReader bridge = new InputStreamReader(in);
		BufferedReader br = new BufferedReader(bridge);
		String line=null;
			while(true){
				try {
						line = br.readLine();
					} catch (IOException e) {
						e.printStackTrace();
					}
					if(line.isEmpty())
						break;
					System.out.println(line);
		}
		
		
			
		
		System.out.println("printing");
		
		PrintWriter pr = new PrintWriter(soc.getOutputStream());
		/*pr.println("HTTP/1.1 200 OK");
	    pr.println("Content-Type: text/html");
	    pr.println("\r\n");
	    pr.println("<p> Hello world </p>");*/
		pr.write("HTTP/1.1 200 OK");
		pr.write("Date: Mon, 4 Oct 2016 12:28:53 GMT");
		pr.write("Server: Apache/2.2.14 (Win32)");
		pr.write("Content-Length: 88");
		pr.write("Content-Type: text/html");
		pr.write("Connection: Closed");
		pr.println("\r\n");
		pr.write("<html><body><h1>Hello, World!</h1></body></html>");
		pr.flush();
		pr.close();
		soc.close();
		
	}
}
